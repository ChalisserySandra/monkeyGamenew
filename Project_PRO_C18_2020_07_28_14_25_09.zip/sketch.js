//Global Variables



function preload(){
  
}


function setup() {
  createCanvas(600,300);
}


function draw(){
 background(255); 
}